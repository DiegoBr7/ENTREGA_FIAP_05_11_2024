package br.com.fiap.fiap_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiapGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
