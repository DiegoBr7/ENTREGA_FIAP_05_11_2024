package br.com.fiap.fiap_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiapGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiapGatewayApplication.class, args);
	}

}
